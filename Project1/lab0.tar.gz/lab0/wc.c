#include <stdio.h>
#include <ctype.h>

void wc(FILE *ofile, FILE *infile, char *inname) {
}

int main (int argc, char *argv[]) {
    return 0;
}
